# orbbec_robotCatch

硬件配置： Astra pro深度相机；Zora P1开发板

## 环境要求
1. pcl 1.8
2. opencv 3.2

